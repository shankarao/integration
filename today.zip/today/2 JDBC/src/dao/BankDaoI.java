package dao;

import java.sql.SQLException;

import bean.BankBean;
import bean.BankTransaction;

public interface BankDaoI {



	public void InsertData(long accNo, BankBean bean) throws ClassNotFoundException, SQLException;
	
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException;

	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException;

	public BankBean getAccountDetails(long accNo) throws ClassNotFoundException, SQLException;

	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException;

	public BankTransaction getTransactions(long accNo) throws ClassNotFoundException, SQLException;

}
