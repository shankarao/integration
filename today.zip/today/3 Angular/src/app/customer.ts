export class Customer
 {
     accountNo:number;
    firstName:string;
     emailId:string;
     password:string;
    username:string;
     aadharNo:string;
     mobileNo:string;
     balance:number;
}