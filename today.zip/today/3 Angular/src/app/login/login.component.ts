import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { Router } from '@angular/router';
import { BankServiceService } from '../bank-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  
  constructor(private router: Router, private userService:BankServiceService) { 
    
  }
    
  ngOnInit() {
 
  }

  login(username,password){
    this.userService.login(username,password).subscribe(data=>{
      this.userService.setAccountNumber(data);
      alert(this.userService.getAccountNumber())
      this.router.navigate(['/homecomponent']);
      },error=>{alert("Wrong credentials")});
  };

}
