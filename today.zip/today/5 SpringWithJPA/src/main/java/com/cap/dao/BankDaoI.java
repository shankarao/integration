package com.cap.dao;

import java.util.List;

import com.cap.entities.Bank;
import com.cap.entities.Transaction;

public interface BankDaoI {
   boolean createAccount(Bank bank);
   int showBalance(long accountNo);
   int depositBalance(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validateAccount(long accountNo,String password);
	public List<Transaction> getTransactions(long accountNo) ;
	


}
